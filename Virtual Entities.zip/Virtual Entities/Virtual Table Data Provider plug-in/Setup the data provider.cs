﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace Virtual_Table_Data_Provider_plug_in
{
    public class Setup_the_data_provider : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            var context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            //if (context.Stage ==20) 
            //{
            //    context.SharedVariables["connectionstring"] = connectionString;
            //    return;
            //}
            if (context.MessageName == "RetriveMutliple")
            {
                if (context.Stage == 30)
                {
                    string keyword = null;
                    Guid recordId = Guid.Empty;
                    var qe = (QueryExpression)context.Inputparameters["Query"];
                    if (qe.Criteria.Conditions.Count > 0)
                    {
                        //this is to support
                        //new_testvirtualentities?$filter=new_testvirtualentityid+eq+...
                        ParseConditionCollection(qe.Criteria.Conditions, ref keyword, ref recordId);
                    }
                    else if (qe.Criteria.Filters.Count > 0)
                    {
                        //This is for "Search"
                        ParseConditionCollection(qe.Criteria.Filters[0].Condidtions, ref keyword, ref recordId);
                    }
                    if (keyword != null && keyword.StartsWith("[%]")) keyword = "%" + (keyword.Length > 2 ? keyword.Substring(3) : "");
                    loadEntities(context, keyword, recordId);
                    context.Outputparameters["BusinessEntityCollection"] = ec;

                }
            }
            else if (context.MessageName == "Retrieve")
            {
                loadEntities(context, null, context.PrimaryEntityId);
                context.OutputParameters["BusinessEntityCollection"] = ec.Entities.ToList().Find(else => else.Id == context.PrimaryEntityId);
            }
        }

    }
}
