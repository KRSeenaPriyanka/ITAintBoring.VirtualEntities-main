﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Virtual_Entity_Azure_SQL_web_API
{
    public class VirtualEntity_Retrieve_Records
    {
    }
}
