SELECT
      ,[First Name]
      ,[Last Name]
      ,[Email]
     
  FROM [Virtual Entities]